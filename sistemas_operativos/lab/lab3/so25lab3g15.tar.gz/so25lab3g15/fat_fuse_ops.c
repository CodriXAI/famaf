/*
 * fat_fuse_ops.c
 *
 * FAT32 filesystem operations for FUSE (Filesystem in Userspace)
 */

#include "fat_fuse_ops.h"
#include "big_brother.h"
#include "fat_filename_util.h"
#include "fat_util.h"
/* fat_file, fat_fs_tree and fat_table.h contained in fat_volume.h */
#include "fat_volume.h"
#include <alloca.h>
#include <errno.h>
#include <gmodule.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define LOG_MESSAGE_SIZE 100
#define DATE_MESSAGE_SIZE 30

static void now_to_str(char *buf) {
    time_t now = time(NULL);
    struct tm *timeinfo;
    timeinfo = localtime(&now);

    strftime(buf, DATE_MESSAGE_SIZE, "%d-%m-%Y %H:%M", timeinfo);
}

/*
    Records the user's read and write activity within the fs.log file:
        @operation_type: Whether it was reading or writing.
        @file: file that the activity was performed.
*/
static void fat_fuse_log_activity(char *operation_type, fat_file file) {

    /* Load the message to be recorded into the buffer */
    char buf[LOG_MESSAGE_SIZE] = "";
    now_to_str(buf);
    strcat(buf, "\t");
    strcat(buf, getlogin());
    strcat(buf, "\t");
    strcat(buf, file->filepath);
    strcat(buf, "\t");
    strcat(buf, operation_type);
    strcat(buf, "\n");

    /* Append (not overwrite) string to BB_LOG_FILE (/bb/fs.log) */
    struct stat stbuf;
    int getattr_res = fat_fuse_getattr(BB_LOG_FILE, &stbuf);

    if (getattr_res != 0) {
        fprintf(stderr,
                "LOGGING ERROR: could not get information from /bb/fs.log");
        return;
    }

    /* Getting context */
    fat_volume vol = get_fat_volume();
    fat_tree_node log_node = fat_tree_node_search(vol->file_tree, BB_LOG_FILE);

    if (log_node == NULL) {
        fprintf(stderr, "LOGGING ERROR: /bb/fs.log node not found in tree.");
        return;
    }

    /* Log file location */
    fat_file log_file = fat_tree_get_file(log_node);
    fat_file parent_dir = fat_tree_get_parent(log_node);

    /* Append the string in the right position */
    off_t log_offset = stbuf.st_size;
    size_t str_size = strlen(buf);

    /* Writing the received record */
    fat_file_pwrite(log_file, buf, str_size, log_offset, parent_dir);
}

/* Loads directory children from the volume into in-memory tree.
 * Calls function fat_file_read_children which returns
 * a list of files inside a GList. The children were read from the directory
 * entries in the cluster of the directory. This function iterates over the
 * list of children and adds them to the file tree.
 * This operation should be performed only once per directory, the first time
 * readdir is called.
 */
static void fat_fuse_load_directory_children(fat_volume vol,
                                             fat_tree_node dir_node) {
    fat_file dir = fat_tree_get_file(dir_node);
    GList *children_list = fat_file_read_children(dir);
    // Add children to tree. TODO handle duplicates
    for (GList *l = children_list; l != NULL; l = l->next) {
        vol->file_tree =
            fat_tree_insert(vol->file_tree, dir_node, (fat_file)l->data);
    }
}

/* ======================= PART 2 MODULES ======================== */

/* Given the @vol and the @cluster, we get the cluster value */
static u32 get_cluster_value(fat_volume vol, u32 cluster) {
    return le32_to_cpu(((const le32 *)vol->table->fat_map)[cluster]);
}

/* Finds the first orphan cluster (FAT entry 0xFFFFFFF7) */
static u32 bb_find_orphan_cluster(fat_volume vol) {
    u32 orphan_cluster = 0;
    for (u32 c = 2; c < 10000; c++) {
        if (fat_table_cluster_is_bad_sector(get_cluster_value(vol, c))) {
            DEBUG("[INFO]: Orphan cluster has been found!\n");
            orphan_cluster = c;
            break;
        }
    }

    return orphan_cluster;
}

/* Checks if the orphan cluster contains fs.log */
bool bb_verify_orphan_directory(fat_volume vol, u32 cluster) {
    bool contains_file = false;
    /* Create a temporary directory */
    fat_file tmp_dir =
        fat_file_init_orphan_dir(".bb_orphan", vol->table, cluster);

    /* Create a list with the directory entries */
    GList *children = fat_file_read_children(tmp_dir);

    for (GList *l = children; l != NULL; l = l->next) {
        fat_file f = (fat_file)l->data;
        /* Check if any child is fs.log */
        if (bb_is_log_file_dentry(f->dentry)) {
            contains_file = true;
            break;
        }
    }

    /* Avoid leaks */
    g_list_free_full(children, (GDestroyNotify)fat_file_destroy);
    fat_file_destroy(tmp_dir);

    return contains_file;
}

/* Find and reserve the next free cluster as BAD */
u32 bb_create_orphan_directory_in_cluster(fat_volume vol) {
    /* Gets the next free Cluster and marks it as BAD */
    u32 next_cluster = fat_table_get_next_free_cluster(vol->table);
    fat_table_set_next_cluster(
        vol->table, next_cluster,
        FAT_CLUSTER_BAD_SECTOR); /* Crear el directorio huérfano en ese cluster
                                    y el log */

    return next_cluster;
}

/*
 *   If the directory does not exist, it creates it, if it does not
 *   contain fs.log, it adds it and inserts everything in the tree
 */
void bb_create_orphan_directory(fat_volume vol) {
    u32 orphan_cluster = bb_find_orphan_cluster(vol);

    if (orphan_cluster == 0) {
        DEBUG("¡Orphan directory must be created!");
        orphan_cluster = bb_create_orphan_directory_in_cluster(vol);
        DEBUG("[INFO]: Orphan directory created!");
    }

    /* Create the orphan directory in that cluster and the log */
    fat_file bb_dir =
        fat_file_init_orphan_dir(BB_DIRNAME, vol->table, orphan_cluster);

    if (!bb_verify_orphan_directory(vol, orphan_cluster)) {
        /* Add the fs.log to the /bb directory and insert the
        directory to the tree. */
        fat_file log_file =
            fat_file_init(vol->table, false, strdup(BB_LOG_FILE));
        fat_file_dentry_add_child(bb_dir, log_file);
    }

    /*
     *  The orphan directory with the fs.log is inserted into
     *  the tree. It is always integrated into the system, whether
     *  it exists or not.
     */
    fat_tree_node root_node = fat_tree_node_search(vol->file_tree, "/");
    vol->file_tree = fat_tree_insert(vol->file_tree, root_node, bb_dir);
}

fat_volume fat_fuse_init(fat_volume vol) {
    fat_file root_dir =
        fat_file_init_orphan_dir("/", vol->table, vol->root_dir_start_cluster);
    vol->file_tree = fat_tree_init();
    vol->file_tree = fat_tree_insert(vol->file_tree, NULL, root_dir);

    // Load the content of / to the tree
    fat_tree_node root_dir_node = fat_tree_node_search(vol->file_tree, "/");
    fat_fuse_load_directory_children(vol, root_dir_node);
    fat_tree_print_preorder(vol->file_tree);

    /* Lab 3 part 2 */
    bb_create_orphan_directory(vol);

    return vol;
}

/* Get file attributes (file descriptor version) */
int fat_fuse_fgetattr(const char *path, struct stat *stbuf,
                      struct fuse_file_info *fi) {
    fat_file file = (fat_file)fat_tree_get_file((fat_tree_node)fi->fh);
    fat_file_to_stbuf(file, stbuf);
    return 0;
}

/* Load the entire hierarchy of parent directories in the in-memory tree.
 * IMPORTANT: Asumes the rood directory / has been already loaded
 */
static int fat_fuse_load_path(const char *path) {
    fat_volume vol = get_fat_volume();
    size_t len = strlen(path);
    char *prefix = calloc(len + 1, sizeof(char));
    for (size_t i = 1; i <= len; i++) {
        if (path[i] != '/')
            continue;
        if (path[i] == '\0')
            break; // End of path
        // We found a path delimiter /, we take everything up to there
        memcpy(prefix, path, i);
        prefix[i] = '\0';

        fat_tree_node dir_node = fat_tree_node_search(vol->file_tree, prefix);
        if (dir_node == NULL) {
            // This doesn't happen because the parent was added in the
            // previous iteration.
            DEBUG("Directory %s not found in tree\n", prefix);
            errno = ENOENT;
            return -errno;
        }
        fat_file dir = fat_tree_get_file(dir_node);
        if (!fat_file_is_directory(dir)) {
            DEBUG("Directory %s is not a directory\n", prefix);
            errno = ENOTDIR;
            return -errno;
        }
        if (dir->children_read != 1) {
            fat_fuse_load_directory_children(vol, dir_node);
        }
    }
    free(prefix);
    return 0;
}

/* Get file attributes (path version) */
int fat_fuse_getattr(const char *path, struct stat *stbuf) {
    fat_volume vol;
    fat_file file;

    // Get a pointer to the FAT volume that is currently mounted
    vol = get_fat_volume();
    // Check all parent directories in path are loaded in the tree
    fat_fuse_load_path(path);

    file = fat_tree_search(vol->file_tree, path);
    if (file == NULL) {
        errno = ENOENT;
        return -errno;
    }
    fat_file_to_stbuf(file, stbuf);
    return 0;
}

/* Open a file */
int fat_fuse_open(const char *path, struct fuse_file_info *fi) {
    fat_volume vol;
    fat_tree_node file_node;
    fat_file file;

    vol = get_fat_volume();
    file_node = fat_tree_node_search(vol->file_tree, path);
    if (!file_node)
        return -errno;
    file = fat_tree_get_file(file_node);
    if (fat_file_is_directory(file))
        return -EISDIR;
    fat_tree_inc_num_times_opened(file_node);
    fi->fh = (uintptr_t)file_node;
    return 0;
}

/* Open a directory */
int fat_fuse_opendir(const char *path, struct fuse_file_info *fi) {
    fat_volume vol = NULL;
    fat_tree_node file_node = NULL;
    fat_file file = NULL;

    vol = get_fat_volume();
    file_node = fat_tree_node_search(vol->file_tree, path);
    if (file_node == NULL) {
        return -errno;
    }
    file = fat_tree_get_file(file_node);
    if (!fat_file_is_directory(file)) {
        return -ENOTDIR;
    }
    fat_tree_inc_num_times_opened(file_node);
    fi->fh = (uintptr_t)file_node;
    return 0;
}

/* Add entries of a directory in @fi to @buf using @filler function. */
int fat_fuse_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                     off_t offset, struct fuse_file_info *fi) {
    fat_volume vol = get_fat_volume();
    errno = 0;
    fat_tree_node dir_node = (fat_tree_node)fi->fh;
    fat_file dir = fat_tree_get_file(dir_node);
    fat_file *children = NULL, *child = NULL;
    int error = 0;

    // Insert first two filenames (. and ..)
    if ((*filler)(buf, ".", NULL, 0) || (*filler)(buf, "..", NULL, 0)) {
        return -errno;
    }
    if (!fat_file_is_directory(dir)) {
        errno = ENOTDIR;
        return -errno;
    }
    if (dir->children_read != 1) {
        fat_fuse_load_directory_children(vol, dir_node);
        if (errno < 0) {
            return -errno;
        }
    }

    children = fat_tree_flatten_h_children(dir_node);
    child = children;
    while (*child != NULL) {
        /* Variable that indicates if there is an imposter */
        int impostor = 0;

        /* If bb or fs.log was listed, this is an imposter */
        if (strcmp((*child)->name, "bb") == 0 ||
            strcmp((*child)->name, "fs.log") == 0) {
            impostor = 1;
        }

        /* Look to see if there were impostors */
        switch (impostor) {
        case 0:
            error = (*filler)(buf, (*child)->name, NULL, 0);
            break;
        default:
            break;
        }

        if (error != 0) {
            DEBUG("Error in readdir: %s\n", dir->filepath);
            break;
        }
        child++;

        /* Reset to detect if there is another imposter */
        impostor = 0;
    }
    return 0;
}

/* Read data from a file */
int fat_fuse_read(const char *path, char *buf, size_t size, off_t offset,
                  struct fuse_file_info *fi) {
    errno = 0;
    int bytes_read;
    fat_tree_node file_node = (fat_tree_node)fi->fh;
    fat_file file = fat_tree_get_file(file_node);
    fat_file parent = fat_tree_get_parent(file_node);

    bytes_read = fat_file_pread(file, buf, size, offset, parent);

    /* Log the activity only if it is not the log file
    to avoid infinite recursion. */
    if (bytes_read > 0 && strcmp(path, BB_LOG_FILE) != 0)
        fat_fuse_log_activity("READ", file);

    return bytes_read;
}

/* Write data from a file */
int fat_fuse_write(const char *path, const char *buf, size_t size, off_t offset,
                   struct fuse_file_info *fi) {
    fat_tree_node file_node = (fat_tree_node)fi->fh;
    fat_file file = fat_tree_get_file(file_node);
    fat_file parent = fat_tree_get_parent(file_node);

    if (size == 0)
        return 0; // Nothing to write
    if (offset > file->dentry->file_size)
        return -EOVERFLOW;

    ssize_t bytes_written = fat_file_pwrite(file, buf, size, offset, parent);

    /* Log the activity only if it is not the log file
    to avoid infinite recursion. */
    if (bytes_written > 0 && strcmp(path, BB_LOG_FILE) != 0)
        fat_fuse_log_activity("WRITE", file);

    return bytes_written;
}
/* Close a file */
int fat_fuse_release(const char *path, struct fuse_file_info *fi) {
    fat_tree_node file = (fat_tree_node)fi->fh;
    fat_tree_dec_num_times_opened(file);
    return 0;
}

/* Close a directory */
int fat_fuse_releasedir(const char *path, struct fuse_file_info *fi) {
    fat_tree_node file = (fat_tree_node)fi->fh;
    fat_tree_dec_num_times_opened(file);
    return 0;
}

int fat_fuse_mkdir(const char *path, mode_t mode) {
    errno = 0;
    fat_volume vol = NULL;
    fat_file parent = NULL, new_file = NULL;
    fat_tree_node parent_node = NULL;

    // The system has already checked the path does not exist. We get the parent
    vol = get_fat_volume();
    parent_node = fat_tree_node_search(vol->file_tree, dirname(strdup(path)));
    if (parent_node == NULL) {
        errno = ENOENT;
        return -errno;
    }
    parent = fat_tree_get_file(parent_node);
    if (!fat_file_is_directory(parent)) {
        fat_error("Error! Parent is not directory\n");
        errno = ENOTDIR;
        return -errno;
    }

    // init child
    new_file = fat_file_init(vol->table, true, strdup(path));
    if (errno != 0) {
        return -errno;
    }
    // insert to directory tree representation
    vol->file_tree = fat_tree_insert(vol->file_tree, parent_node, new_file);
    // write file in parent's entry (disk)
    fat_file_dentry_add_child(parent, new_file);
    return -errno;
}

/* Creates a new file in @path. @mode and @dev are ignored. */
int fat_fuse_mknod(const char *path, mode_t mode, dev_t dev) {
    errno = 0;
    fat_volume vol;
    fat_file parent, new_file;
    fat_tree_node parent_node;

    // The system has already checked the path does not exist. We get the parent
    vol = get_fat_volume();
    parent_node = fat_tree_node_search(vol->file_tree, dirname(strdup(path)));
    if (parent_node == NULL) {
        errno = ENOENT;
        return -errno;
    }
    parent = fat_tree_get_file(parent_node);
    if (!fat_file_is_directory(parent)) {
        fat_error("Error! Parent is not directory\n");
        errno = ENOTDIR;
        return -errno;
    }
    new_file = fat_file_init(vol->table, false, strdup(path));
    if (new_file == NULL) {
        return -errno;
    }
    // insert to directory tree representation
    vol->file_tree = fat_tree_insert(vol->file_tree, parent_node, new_file);
    // Write dentry in parent cluster
    fat_file_dentry_add_child(parent, new_file);
    return -errno;
}

int fat_fuse_utime(const char *path, struct utimbuf *buf) {
    errno = 0;
    fat_file parent = NULL;
    fat_volume vol = get_fat_volume();
    fat_tree_node file_node = fat_tree_node_search(vol->file_tree, path);
    if (file_node == NULL || errno != 0) {
        errno = ENOENT;
        return -errno;
    }
    parent = fat_tree_get_parent(file_node);
    if (parent == NULL || errno != 0) {
        DEBUG("WARNING: Setting time for parent ignored");
        return 0; // We do nothing, no utime for parent
    }
    fat_utime(fat_tree_get_file(file_node), parent, buf);
    return -errno;
}

/* Shortens the file at the given offset.*/
int fat_fuse_truncate(const char *path, off_t offset) {
    errno = 0;
    fat_volume vol = get_fat_volume();
    fat_file file = NULL, parent = NULL;
    fat_tree_node file_node = fat_tree_node_search(vol->file_tree, path);
    if (file_node == NULL || errno != 0) {
        errno = ENOENT;
        return -errno;
    }
    file = fat_tree_get_file(file_node);
    if (fat_file_is_directory(file))
        return -EISDIR;

    parent = fat_tree_get_parent(file_node);
    fat_tree_inc_num_times_opened(file_node);
    fat_file_truncate(file, offset, parent);
    return -errno;
}

int fat_fuse_unlink(const char *path) {
    int result = 0;
    errno = 0;
    fat_volume vol = get_fat_volume();
    fat_file file = NULL;
    fat_file parent = NULL;
    fat_tree_node file_node = fat_tree_node_search(vol->file_tree, path);

    if (file_node == NULL || errno != 0) {
        errno = ENOENT;
        return -ENOENT;
    }

    file = fat_tree_get_file(file_node);

    if (fat_file_is_directory(file)) {
        return EISDIR;
    }

    parent = fat_tree_get_parent(file_node);
    u32 current_cluster = file->start_cluster;
    u32 next_cluster;

    while (fat_table_cluster_is_valid(current_cluster)) {
        next_cluster = fat_table_get_next_cluster(file->table, current_cluster);
        fat_table_set_next_cluster(file->table, current_cluster,
                                   FAT_CLUSTER_FREE);
        current_cluster = next_cluster;
    }

    file->dentry->base_name[0] = FILE_FOR_DELETION;
    off_t parent_offset =
        fat_table_cluster_offset(parent->table, parent->start_cluster);
    size_t entry_size = sizeof(struct fat_dir_entry_s);
    off_t entry_offset = parent_offset + (file->pos_in_parent * entry_size);
    ssize_t bytes_written =
        pwrite(parent->table->fd, file->dentry, entry_size, entry_offset);

    if (parent && fat_file_is_directory(parent) && parent->dir.nentries > 0) {
        parent->dir.nentries--;
    }

    if (bytes_written < (ssize_t)entry_size) {
        return -EIO;
    }

    vol->file_tree = fat_tree_delete(vol->file_tree, path);
    result = -errno;

    DEBUG("File Removed");
    return result;
}

int fat_fuse_rmdir(const char *path) {
    int result = 0;
    errno = 0;
    fat_volume vol = get_fat_volume();
    fat_file directory = NULL;
    fat_file parent = NULL;
    fat_tree_node directory_node = fat_tree_node_search(vol->file_tree, path);

    if (directory_node == NULL || errno != 0) {
        errno = ENOENT;
        return -ENOENT;
    }

    directory = fat_tree_get_file(directory_node);

    if (!fat_file_is_directory(directory)) {
        return -ENOTDIR;
    }

    DEBUG("Entries in dir '%s': %d", path, directory->dir.nentries);

    GList *children = fat_file_read_children(directory);
    bool has_real_children = false;
    for (GList *l = children; l != NULL; l = l->next) {
        fat_file f = (fat_file)l->data;
        if (f->dentry->base_name[0] != FILE_FOR_DELETION &&
            strcmp((char *)f->dentry->base_name, ".") != 0 &&
            strcmp((char *)f->dentry->base_name, "..") != 0) {
            has_real_children = true;
            break;
        }
    }

    g_list_free(children);

    if (has_real_children) {
        return -ENOTEMPTY;
    }

    parent = fat_tree_get_parent(directory_node);
    u32 current_cluster = directory->start_cluster;
    u32 next_cluster;

    while (fat_table_cluster_is_valid(current_cluster)) {
        next_cluster =
            fat_table_get_next_cluster(directory->table, current_cluster);
        fat_table_set_next_cluster(directory->table, current_cluster,
                                   FAT_CLUSTER_FREE);
        current_cluster = next_cluster;
    }

    directory->dentry->base_name[0] = FILE_FOR_DELETION;
    off_t parent_offset =
        fat_table_cluster_offset(parent->table, parent->start_cluster);
    size_t entry_size = sizeof(struct fat_dir_entry_s);
    off_t entry_offset =
        parent_offset + (directory->pos_in_parent * entry_size);
    ssize_t bytes_written =
        pwrite(parent->table->fd, directory->dentry, entry_size, entry_offset);

    if (bytes_written < (ssize_t)entry_size) {
        return -EIO;
    }

    vol->file_tree = fat_tree_delete(vol->file_tree, path);
    result = -errno;

    DEBUG("Directory Removed");
    return result;
}
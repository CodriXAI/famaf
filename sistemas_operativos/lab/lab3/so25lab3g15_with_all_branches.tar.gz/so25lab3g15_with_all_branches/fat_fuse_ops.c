/*
 * fat_fuse_ops.c
 *
 * FAT32 filesystem operations for FUSE (Filesystem in Userspace)
 */

#include "fat_fuse_ops.h"

#include "big_brother.h"
#include "fat_file.h"
#include "fat_filename_util.h"
#include "fat_fs_tree.h"
#include "fat_table.h" /* útil para poder trabajar a nivel clusters*/
#include "fat_util.h"
#include "fat_volume.h"
#include <alloca.h>
#include <errno.h>
#include <gmodule.h>
#include <libgen.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define LOG_MESSAGE_SIZE 100
#define DATE_MESSAGE_SIZE 30

static void now_to_str(char *buf) {
    time_t now = time(NULL);
    struct tm *timeinfo;
    timeinfo = localtime(&now);

    strftime(buf, DATE_MESSAGE_SIZE, "%d-%m-%Y %H:%M", timeinfo);
}

static void fat_fuse_log_activity(char *operation_type, fat_file file) {
    if (file == NULL) return;
    char buf[LOG_MESSAGE_SIZE] = "";
    now_to_str(buf);
    strcat(buf, "\t");
    strcat(buf, getlogin());
    strcat(buf, "\t");
    strcat(buf, file->filepath);
    strcat(buf, "\t");
    strcat(buf, operation_type);
    strcat(buf, "\n");
    
    
    // Append (not overwrite) string to /bb/fs.log 
    struct stat stbuf;   
    /* Modificada la ruta para la parte 2 */
    int getattr_res = fat_fuse_getattr(BB_LOG_FILE, &stbuf); 

    if (getattr_res != 0)  {
        fprintf(stderr, "LOGGING ERROR: could not get information from /bb/fs.log"); 
        return; 
    }
    
    fat_volume vol = fuse_get_context()->private_data; 
    fat_tree_node log_node = fat_tree_node_search(vol->file_tree, BB_LOG_FILE);

    if (log_node == NULL) {
        fprintf(stderr, "LOGGING ERROR: /bb/fs.log node not found in tree.");
        return;
    }

    fat_file log_file = fat_tree_get_file(log_node);
    fat_file parent_dir = fat_tree_get_parent(log_node);

    off_t log_offset = stbuf.st_size; // so that i can append the string in the right position
    size_t str_size = strlen(buf);
        
    /* aca debo escribir en el fs.log */
    fat_file_pwrite(log_file, buf, str_size, log_offset, parent_dir);

    DEBUG("ARCHIVO = %s", buf);
}

/* Loads directory children from the volume into in-memory tree.
 * Calls function fat_file_read_children which returns
 * a list of files inside a GList. The children were read from the directory
 * entries in the cluster of the directory. This function iterates over the
 * list of children and adds them to the file tree.
 * This operation should be performed only once per directory, the first time
 * readdir is called.
 */
static void fat_fuse_load_directory_children(fat_volume vol, fat_tree_node dir_node) {
    fat_file dir = fat_tree_get_file(dir_node);
    GList *children_list = fat_file_read_children(dir);
    // Add children to tree. TODO handle duplicates
    for (GList *l = children_list; l != NULL; l = l->next) {
        vol->file_tree =
            fat_tree_insert(vol->file_tree, dir_node, (fat_file)l->data);
    }
}

/* Dado el @vol y el @cluster, obtenemos su valor de validez */
static u32 get_cluster_value(fat_volume vol, u32 cluster){
    return le32_to_cpu(((const le32 *)vol->table->fat_map)[cluster]);
}

/* Finds the first orphan cluster (FAT entry 0xFFFFFFF7) */
static u32 bb_find_orphan_cluster(fat_volume vol) {
    u32 orphan_cluster = 0;
    for(u32 c = 2; c < 10000; c++){
        if(fat_table_cluster_is_bad_sector(get_cluster_value(vol, c))){
            DEBUG("[INFO]: Orphan cluster has been found!\n");
            orphan_cluster = c;
            break; 
        }
    }
    
    
    return orphan_cluster;
}

/* Checks if the orphan cluster contains fs.log */
bool bb_verify_orphan_directory(fat_volume vol, u32 cluster) {
    bool contains_file = false; 
    /* creo un directorio temporal */
    fat_file tmp_dir = fat_file_init_orphan_dir(".bb_orphan", vol->table, cluster);
    
    /* creo una lista con las entradas del directorio */
    GList *children = fat_file_read_children(tmp_dir);

    for (GList *l = children; l != NULL; l = l->next) {
            fat_file f = (fat_file)l->data;
            /* verifico si algun hijo es fs.log */
            if (bb_is_log_file_dentry(f->dentry)){
                contains_file = true; 
                break; 
            }
        }
    g_list_free_full(children, (GDestroyNotify)fat_file_destroy);
    fat_file_destroy(tmp_dir);


    return contains_file; 
}

u32 bb_create_orphan_directory_in_cluster(fat_volume vol) {
    /* Obtengo el siguiente Cluster libre y lo marco como BAD*/
    u32 next_cluster = fat_table_get_next_free_cluster(vol->table);
    fat_table_set_next_cluster(vol->table, next_cluster, FAT_CLUSTER_BAD_SECTOR);  /* Crear el directorio huérfano en ese cluster y el log */
    


    return next_cluster; 
}

void bb_create_orphan_directory(fat_volume vol) {
    u32 orphan_cluster = bb_find_orphan_cluster(vol); 

    if (orphan_cluster == 0) {
        DEBUG("Debo crear el cluster huerfano");
        orphan_cluster = bb_create_orphan_directory_in_cluster(vol);
        DEBUG("[INFO]: Orphan directory created!");
    } 

    
    /* Crear el directorio huérfano en ese cluster y el log */
    fat_file bb_dir = fat_file_init_orphan_dir(BB_DIRNAME, vol->table, orphan_cluster);
    
    if (!bb_verify_orphan_directory(vol, orphan_cluster)) {
        fat_file log_file = fat_file_init(vol->table, false, strdup(BB_LOG_FILE));
        /*Agregar el fs.log al directorio /bb e insertamos el 
        directorio al árbol*/
        fat_file_dentry_add_child(bb_dir, log_file);
    }

    // Lo integro siempre al sistema, exista o no 
    /* Insertamos en el árbol el directorio huérfano con el fs.log*/
    fat_tree_node root_node = fat_tree_node_search(vol->file_tree, "/");
    vol->file_tree = fat_tree_insert(vol->file_tree, root_node, bb_dir); 
}


fat_volume fat_fuse_init(fat_volume vol) {
    fat_file root_dir = fat_file_init_orphan_dir("/", vol->table, vol->root_dir_start_cluster);
    vol->file_tree = fat_tree_init();
    vol->file_tree = fat_tree_insert(vol->file_tree, NULL, root_dir);

    // Load the content of / to the tree
    fat_tree_node root_dir_node = fat_tree_node_search(vol->file_tree, "/");
    fat_fuse_load_directory_children(vol, root_dir_node);
    fat_tree_print_preorder(vol->file_tree);

   /* lab 3 parte 2 */ 
   bb_create_orphan_directory(vol);


    return vol;
}

/* Get file attributes (file descriptor version) */
int fat_fuse_fgetattr(const char *path, struct stat *stbuf,
                      struct fuse_file_info *fi) {
    fat_file file = (fat_file)fat_tree_get_file((fat_tree_node)fi->fh);
    fat_file_to_stbuf(file, stbuf);
    return 0;
}

/* Load the entire hierarchy of parent directories in the in-memory tree.
 * IMPORTANT: Asumes the rood directory / has been already loaded
 */
static int fat_fuse_load_path(const char *path) {
    fat_volume vol = get_fat_volume();
    size_t len = strlen(path);
    char *prefix = calloc(len + 1, sizeof(char));
    for (size_t i = 1; i <= len; i++) {
        if (path[i] != '/') continue;
        if (path[i] == '\0') break;  // End of path
        // We found a path delimiter /, we take everything up to there
        memcpy(prefix, path, i);
        prefix[i] = '\0';

        fat_tree_node dir_node = fat_tree_node_search(vol->file_tree, prefix);
        if (dir_node == NULL) {
            // This doesn't happen because the parent was added in the
            // previous iteration.
            DEBUG("Directory %s not found in tree\n", prefix);
            errno = ENOENT;
            return -errno;
        }
        fat_file dir = fat_tree_get_file(dir_node);
        if (!fat_file_is_directory(dir)) {
            DEBUG("Directory %s is not a directory\n", prefix);
            errno = ENOTDIR;
            return -errno;
        }
        if (dir->children_read != 1) {
            fat_fuse_load_directory_children(vol, dir_node);
        }
    }
    free(prefix);
    return 0;
}

/* Get file attributes (path version) */
int fat_fuse_getattr(const char *path, struct stat *stbuf) {
    fat_volume vol;
    fat_file file;

    vol = get_fat_volume();

    // Check all parent directories in path are loaded in the tree
    fat_fuse_load_path(path);

    file = fat_tree_search(vol->file_tree, path);
    if (file == NULL) {
        errno = ENOENT;
        return -errno;
    }
    fat_file_to_stbuf(file, stbuf);
    return 0;
}

/* Open a file */
int fat_fuse_open(const char *path, struct fuse_file_info *fi) {
    fat_volume vol;
    fat_tree_node file_node;
    fat_file file;

    vol = get_fat_volume();
    file_node = fat_tree_node_search(vol->file_tree, path);
    if (!file_node)
        return -errno;
    file = fat_tree_get_file(file_node);
    if (fat_file_is_directory(file))
        return -EISDIR;
    fat_tree_inc_num_times_opened(file_node);
    fi->fh = (uintptr_t)file_node;
    return 0;
}

/* Open a directory */
int fat_fuse_opendir(const char *path, struct fuse_file_info *fi) {
    fat_volume vol = NULL;
    fat_tree_node file_node = NULL;
    fat_file file = NULL;

    vol = get_fat_volume();
    file_node = fat_tree_node_search(vol->file_tree, path);
    if (file_node == NULL) {
        return -errno;
    }
    file = fat_tree_get_file(file_node);
    if (!fat_file_is_directory(file)) {
        return -ENOTDIR;
    }
    fat_tree_inc_num_times_opened(file_node);
    fi->fh = (uintptr_t)file_node;
    return 0;
}

/* Add entries of a directory in @fi to @buf using @filler function. */
int fat_fuse_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
                     off_t offset, struct fuse_file_info *fi) {
    fat_volume vol = get_fat_volume();
    errno = 0;
    fat_tree_node dir_node = (fat_tree_node)fi->fh;
    fat_file dir = fat_tree_get_file(dir_node);
    fat_file *children = NULL, *child = NULL;
    int error = 0;

    // Insert first two filenames (. and ..)
    if ((*filler)(buf, ".", NULL, 0) || (*filler)(buf, "..", NULL, 0)) {
        return -errno;
    }
    if (!fat_file_is_directory(dir)) {
        errno = ENOTDIR;
        return -errno;
    }
    if (dir->children_read != 1) {
        fat_fuse_load_directory_children(vol, dir_node);
        if (errno < 0) {
            return -errno;
        }
    }

    children = fat_tree_flatten_h_children(dir_node);
    child = children;
    while (*child != NULL) {
        /*If fs.log is found, it will not be taken into account*/
         if(strcmp((*child)->name, "fs.log") != 0){
            error = (*filler)(buf, (*child)->name, NULL, 0);
        }
        if (error != 0) {
            DEBUG("Error in readdir: %s\n", dir->filepath);
            break;
        }
        child++;
    }
    return 0;
}

/* Read data from a file */
int fat_fuse_read(const char *path, char *buf, size_t size, off_t offset,
                  struct fuse_file_info *fi) {
    errno = 0;
    int bytes_read;
    fat_tree_node file_node = (fat_tree_node)fi->fh;
    fat_file file = fat_tree_get_file(file_node);
    fat_file parent = fat_tree_get_parent(file_node);

    bytes_read = fat_file_pread(file, buf, size, offset, parent);
    if (bytes_read > 0 && strcmp(path, BB_LOG_FILE) != 0)
        fat_fuse_log_activity("read", file);
    return bytes_read;
}

/* Write data from a file */
int fat_fuse_write(const char *path, const char *buf, size_t size, off_t offset,
                   struct fuse_file_info *fi) {
    fat_tree_node file_node = (fat_tree_node)fi->fh;
    fat_file file = fat_tree_get_file(file_node);
    fat_file parent = fat_tree_get_parent(file_node);

    if (size == 0)
        return 0; // Nothing to write
    if (offset > file->dentry->file_size)
        return -EOVERFLOW;
    int bytes_written = fat_file_pwrite(file, buf, size, offset, parent);
    if (bytes_written > 0 && strcmp(path, BB_LOG_FILE) != 0)
        fat_fuse_log_activity("write", file);
    return bytes_written;
}

/* Close a file */
int fat_fuse_release(const char *path, struct fuse_file_info *fi) {
    fat_tree_node file = (fat_tree_node)fi->fh;
    fat_tree_dec_num_times_opened(file);
    return 0;
}

/* Close a directory */
int fat_fuse_releasedir(const char *path, struct fuse_file_info *fi) {
    fat_tree_node file = (fat_tree_node)fi->fh;
    fat_tree_dec_num_times_opened(file);
    return 0;
}

int fat_fuse_mkdir(const char *path, mode_t mode) {
    errno = 0;
    fat_volume vol = NULL;
    fat_file parent = NULL, new_file = NULL;
    fat_tree_node parent_node = NULL;

    // The system has already checked the path does not exist. We get the parent
    vol = get_fat_volume();
    parent_node = fat_tree_node_search(vol->file_tree, dirname(strdup(path)));
    if (parent_node == NULL) {
        errno = ENOENT;
        return -errno;
    }
    parent = fat_tree_get_file(parent_node);
    if (!fat_file_is_directory(parent)) {
        fat_error("Error! Parent is not directory\n");
        errno = ENOTDIR;
        return -errno;
    }

    // init child
    new_file = fat_file_init(vol->table, true, strdup(path));
    if (errno != 0) {
        return -errno;
    }
    // insert to directory tree representation
    vol->file_tree = fat_tree_insert(vol->file_tree, parent_node, new_file);
    // write file in parent's entry (disk)
    fat_file_dentry_add_child(parent, new_file);
    return -errno;
}

/* Creates a new file in @path. @mode and @dev are ignored. */
int fat_fuse_mknod(const char *path, mode_t mode, dev_t dev) {
    errno = 0;
    fat_volume vol;
    fat_file parent, new_file;
    fat_tree_node parent_node;

    // The system has already checked the path does not exist. We get the parent
    vol = get_fat_volume();
    parent_node = fat_tree_node_search(vol->file_tree, dirname(strdup(path)));
    if (parent_node == NULL) {
        errno = ENOENT;
        return -errno;
    }
    parent = fat_tree_get_file(parent_node);
    if (!fat_file_is_directory(parent)) {
        fat_error("Error! Parent is not directory\n");
        errno = ENOTDIR;
        return -errno;
    }
    new_file = fat_file_init(vol->table, false, strdup(path));
    if (errno < 0) {
        return -errno;
    }
    // insert to directory tree representation
    vol->file_tree = fat_tree_insert(vol->file_tree, parent_node, new_file);
    // Write dentry in parent cluster
    fat_file_dentry_add_child(parent, new_file);
    return -errno;
}

int fat_fuse_utime(const char *path, struct utimbuf *buf) {
    errno = 0;
    fat_file parent = NULL;
    fat_volume vol = get_fat_volume();
    fat_tree_node file_node = fat_tree_node_search(vol->file_tree, path);
    if (file_node == NULL || errno != 0) {
        errno = ENOENT;
        return -errno;
    }
    parent = fat_tree_get_parent(file_node);
    if (parent == NULL || errno != 0) {
        DEBUG("WARNING: Setting time for parent ignored");
        return 0; // We do nothing, no utime for parent
    }
    fat_utime(fat_tree_get_file(file_node), parent, buf);
    return -errno;
}

/* Shortens the file at the given offset.*/
int fat_fuse_truncate(const char *path, off_t offset) {
    errno = 0;
    fat_volume vol = get_fat_volume();
    fat_file file = NULL, parent = NULL;
    fat_tree_node file_node = fat_tree_node_search(vol->file_tree, path);
    if (file_node == NULL || errno != 0) {
        errno = ENOENT;
        return -errno;
    }
    file = fat_tree_get_file(file_node);
    if (fat_file_is_directory(file))
        return -EISDIR;

    parent = fat_tree_get_parent(file_node);
    fat_tree_inc_num_times_opened(file_node);
    fat_file_truncate(file, offset, parent);
    return -errno;
}
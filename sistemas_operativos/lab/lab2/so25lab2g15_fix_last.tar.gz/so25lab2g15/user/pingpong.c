#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"


#define MAX_LENGTH 256

int
main(int argc, char *argv[]){
  if(argc != 2){
    printf("ERROR: Pingpong, requires ONE argument > 0\n");
    exit(1);
  }

  int n = atoi(argv[1]);

  if(n <= 0){
    printf("ERROR: The number of rounds must be greater than 1.\n");
    exit(1);
  }

  int ping = sem_open(-1,1);
  int pong = sem_open(-1,0);

  if(ping == 0 || pong == 0){
    printf("ERROR: Error opening semaphores\n");
    exit(1);
  }

  int pid = fork();
  if(pid == 0){
    for(unsigned int i = 0; i < n; i++){
      sem_down(ping);
      printf("Ping \n");
      sem_up(pong);
    }
    sem_close(ping);
  } else {
    for(unsigned int i = 0; i < n; i++){
      sem_down(pong);
      printf("    Pong \n");
      sem_up(ping);
    }
    wait(0);
    sem_close(pong);
  }
  
  exit(0);
}

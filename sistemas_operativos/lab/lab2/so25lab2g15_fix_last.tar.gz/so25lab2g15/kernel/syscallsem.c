#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "syscall.h"
#include "defs.h"

#define MAX_LENGTH 256

struct sem_t {
  uint name;               // Semaphore name.
  uint init;               // 0 (free/closed), 1 (initialized/open).
  uint value;              // Semaphore counter. (0/1 Binary, our design)
  struct spinlock lk;      // Semaphore spinlock (protects from interrumptions).
  uint lk_processes;       // Number of processes locked/slept.
};

typedef struct sem_t sem;

sem sem_array[MAX_LENGTH];

struct spinlock global_lock;

// Modules for Syscalls

void 
reset_sem(sem *s) 
{
  s->name = 0;
  s->init = 0;
  s->value = 0;
  s->lk_processes = 0;
}

int 
is_valid_sem_id(int sem_id) 
{
  int result;
  result = sem_id > 0 && sem_id < MAX_LENGTH && sem_array[sem_id].init;
  return result;
}

int 
find_sem_by_name(uint name) 
{
  for (int i = 1; i < MAX_LENGTH; i++){
    if(sem_array[i].init && sem_array[i].name == name) 
      return i;
  }
  return 0;
}

int 
create_sem(uint name, uint value) 
{
  for (int i = 1; i < MAX_LENGTH; i++){
    if (!sem_array[i].init) {
      sem_array[i].init = 1;
      sem_array[i].name = name;
      sem_array[i].value = value;
      sem_array[i].lk_processes = 0;
      initlock(&sem_array[i].lk, "sem_spinlock");
      return i;
    }
  }
  return 0;
}

// Responsible for leaving the traffic light arrangement ready and all 
// the locks initialized.
uint64
sem_init(void)
{
  initlock(&global_lock,"global_spinlock");
  for (int i = 0; i < MAX_LENGTH; i++){
    sem_array[i].name = 0;
    sem_array[i].init = 0;
    sem_array[i].value = 0;
    sem_array[i].lk_processes = 0;
  }
  return 1;
}

// Syscalls

uint64
sys_sem_open(void)
{
  int sem_name;
  int sem_value;

  // Get the user space arguments saved in the registers.
  argint(0, &sem_name);
  argint(1, &sem_value);

  acquire(&global_lock);

  // If it does not exist, we initialize it.
  if(sem_name == -1){
    int i = create_sem(sem_name, sem_value);
    release(&global_lock);
    return i; 
  }

  // If look for a particular sem initialized.
  int i = find_sem_by_name(sem_name);
  if (i != 0){
    release(&global_lock);
    return i;
  } 

  // If all semaphores are busy then we have no ID to return.
  release(&global_lock);
  return 0;
}

uint64
sys_sem_close(void)
{
  int sem_id;
  argint (0, &sem_id);

  acquire(&sem_array[sem_id].lk);

  if (!is_valid_sem_id(sem_id)){
    release(&sem_array[sem_id].lk);
    return 0; 
  }

  // If there are waiting/sleeping processes, wake them up and close the semaphore.
  if(sem_array[sem_id].lk_processes > 0){
    wakeup(&sem_array[sem_id]);
    reset_sem(&sem_array[sem_id]);
    release(&sem_array[sem_id].lk);
    return 1;
  }

  if (sem_array[sem_id].lk_processes == 0) 
    reset_sem(&sem_array[sem_id]);

  release(&sem_array[sem_id].lk); 
  return 1;
}

uint64
sys_sem_up(void)
{
  int sem_id;
  argint(0, &sem_id);

  // Avoid race conditions.
  acquire(&sem_array[sem_id].lk); 

  if(!is_valid_sem_id(sem_id)){
    release(&sem_array[sem_id].lk);
    return 0; 
  }

  if(sem_array[sem_id].value == 0) 
    sem_array[sem_id].value = 1;

  if(sem_array[sem_id].lk_processes > 0){
    wakeup(&sem_array[sem_id]);
    sem_array[sem_id].lk_processes--;
  }

  release(&sem_array[sem_id].lk);
  return 1;
}

uint64
sys_sem_down(void)
{
  int sem_id;
  argint(0, &sem_id);

  acquire(&sem_array[sem_id].lk);
  if(!is_valid_sem_id(sem_id)){
    release(&sem_array[sem_id].lk);
    return 0; 
  }

  while(sem_array[sem_id].value == 0){            
    sem_array[sem_id].lk_processes++;
    sleep(&sem_array[sem_id], &sem_array[sem_id].lk);
    
    // On wake up, check if it was closed 
    if(!sem_array[sem_id].init){ 
      release(&sem_array[sem_id].lk); 
      return 0; 
    }
  }
  
  sem_array[sem_id].value = 0;
  release(&sem_array[sem_id].lk);
  return 1;
}